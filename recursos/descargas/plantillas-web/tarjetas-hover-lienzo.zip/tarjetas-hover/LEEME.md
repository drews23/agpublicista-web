# Seis efectos hover para tarjetas — Lienzo Hover Atelier

Seis familias distintas: luz neón, elevación, barrido/revelado, giro 3D, degradado vivo y flotación. HTML/CSS/JS nuevo Lienzo, renders 3D de la Galería de Favicones SVG, fuentes locales, foco de teclado, prueba táctil, temas claro/oscuro y movimiento reducido.

## Abrir, editar y exportar

Descomprime todo el ZIP y abre index.html. Sin servidor, framework, paquetes, API, red, cuenta, analítica ni almacenamiento. Conserva styles.css, script.js, assets/ y los avisos de licencia.

Personalizar edita una tarjeta: título, descripción, texto/destino del enlace, acento Lienzo, duración 200–1000 ms, intensidad 0–100%, radio 16–40 px y curva suave/precisa/elástica. Se refleja de inmediato en la galería y comparación antes/después. Restablecer solo afecta a esa tarjeta. Anterior/siguiente cambia de tarjeta sin perder ajustes. Alterna En reposo y Con efecto en la vista fija. Oculta los ajustes para ampliar la vista previa. Contenido abre primero. Enlace, Apariencia y movimiento y Tu marca son plegables. Repetir muestra temporalmente el efecto; Probar los seis prueba la colección. La pausa y el movimiento reducido detienen efectos móviles y mantienen contenido legible. Hover y foco funcionan sin JavaScript; editor y prueba táctil necesitan el script.

Copiar HTML/Descargar HTML exporta un documento funcional de la tarjeta actual y sus ajustes, o la colección. NO es un archivo completamente autónomo: necesita CSS, JS y assets/ del ZIP junto al HTML. Si el portapapeles se rechaza, ofrece texto seleccionable. Conserva tema y pausa, limpia pruebas temporales y escapa texto introducido. Los enlaces admiten HTTP(S), mailto, /ruta, ./archivo, ../archivo y #fragmento; rechaza esquemas JavaScript/data y barras invertidas. Editar un enlace no lo abre automáticamente. Los enlaces de recursos se abren únicamente al pulsarlos.

## Editar fuentes e integrar

El bloque JSON data-effects guarda key, name, description, label, href, accent, duration, intensity, radius, easing y category. Claves: glow, lift, sweep, rotate, gradient, float. Acentos: mint, violet, amber. Cada tarjeta usa un render WebP local. El acento modifica la superficie y los efectos de la tarjeta. El script valida y limita números. Aplica texto con textContent y destinos con una lista de protocolos admitidos. Estado en memoria; se reinicia al recargar.

Conserva .ln-hover-lab y los hooks data-*/diálogos relevantes al integrar, o adapta el inicio al contenedor. Es HTML/CSS/JS estático, no un componente React ni un tema WordPress. El ZIP completo es la referencia funcional. La interfaz usa la paleta Lienzo por defecto. Los renders conservan sus colores originales. Fraunces conserva su espaciado normal.

## Movimiento y rendimiento

Las capas animadas usan transform y opacity. El barrido/revelado se desplaza con transform, sin animar top/left. La luz neón cambia la opacidad de una sombra estática. Giro de degradado y flotación solo corren al estar visibles; pausa manual, movimiento reducido, pestaña oculta y fondo de modales los detienen. Luz/inclinación de puntero usan geometría guardada y escrituras agrupadas con requestAnimationFrame, sin bucle JS permanente. IntersectionObserver detiene trabajo fuera de pantalla. La comparación anterior queda estática; solo la posterior prueba el efecto. Las mediciones locales no garantizan FPS universales.

## Procedencia y licencias

Se inspeccionaron ultimate-css-card-animation-pack-6-unique-hover-effects.zip y screen-20261013-155959~2.mp4 como referencia. El ZIP contiene nueve tarjetas con clases/nombres repetidos; los selectores compartidos sobrescriben parte del barrido/revelado y la flotación. Esta implementación agrupa las capacidades visuales en seis familias completas, conservando matices de cristal/perspectiva y neón sin colisiones. No redistribuye código, emojis ni estilos de referencia. Las seis tarjetas muestran piezas 3D originales creadas para Lienzo. Cada WebP transparente conserva el color de su fuente. Consulta assets/ICONS-NOTICE.txt para conocer su procedencia. El aviso MIT corresponde al código de la plantilla.

Preparado para la colaboración Lienzo con MD Estudio Creativo identificada por el responsable: https://creativomarketingdigital.com/ . Código MIT en LICENSE-LIENZO.txt; fuentes con OFL. SOURCE-NOTES.md documenta procedencia. MIT no transfiere derechos de marca.


## Mesa de edición
El botón Ajustes pliega el inspector sin restablecer el trabajo. La vista previa permanece estable durante la edición. Conserva editor-workspace.css, editor-workspace.js, editor-legacy.css, editor-legacy.js, template-brand.css y template-brand.js junto al CSS, JavaScript, HTML y assets originales. Estos archivos locales no necesitan red ni instalación.

## Tu marca
Lienzo es la identidad de ejemplo predeterminada. Tu marca admite colores principal, secundario y acento libres, fondo/texto opcionales, fuentes del sistema y archivos WOFF2/WOFF/TTF/OTF locales de hasta 5 MB por función. Los cambios se aplican en directo a la pieza y son independientes de Aplicar/Cancelar contenido. Las exportaciones HTML completas incluyen el perfil y las fuentes adjuntas; conserva las dependencias del ZIP junto al HTML. Los SVG de iconos incluyen sus colores y no necesitan JavaScript; esos dibujos no tienen texto visible y no usan la fuente del editor. Adjunta únicamente fuentes que puedas utilizar y redistribuir. Ningún archivo sale del navegador.
