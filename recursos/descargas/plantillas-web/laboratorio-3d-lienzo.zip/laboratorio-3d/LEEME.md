# Laboratorio de tarjetas 3D — Lienzo

Seis estudios de material: órbita de cristal, corte preciso, relieve neón, plano cinema, prisma de luz y capas flotantes. Superficies separadas, renders 3D originales, tarjeta panorámica, luz direccional y una mesa navegable de seis diseños recuperan la estructura visual e interactiva de la referencia. La implementación es HTML, CSS y JavaScript nuevo de Lienzo.

## Abrir y usar
Descomprime el ZIP completo y abre index.html. Los renders, las fuentes, el logo, CSS y JavaScript son locales. Sin CDN, instalación, API, backend ni compilación. La demo independiente comienza en oscuro; la ventana del sitio sigue el tema de su padre.

Mueve el ratón sobre una tarjeta para inclinarla. Probar efecto ofrece una demostración breve del relieve, también con toque o teclado. Cambiar acento alterna solo entre violeta, menta y ámbar del logo. Copiar HTML exporta esa tarjeta. Personalizar abre un editor nativo con título/descripción en vivo, tres acentos de marca, profundidad de capas (0–48 px) e inclinación máxima (0–14 grados). Restablecer recupera solo la tarjeta elegida. Los ajustes son por tarjeta y se reinician al recargar.

La mesa de pruebas muestra los seis diseños. Usa anterior/siguiente, indicadores numerados, flechas/Inicio/Fin al enfocar el escenario o un gesto horizontal. Los gestos verticales conservan el desplazamiento de la página. La navegación manual se detiene en los extremos. No hay avance automático. Escape cierra el editor y devuelve el foco. Movimiento reducido del sistema o Pausar efectos desactivan inclinación y prueba animada; el relieve estático permanece.

En el editor, Contenido abre primero. Despliega Apariencia y movimiento para ajustar el acento, la profundidad y la inclinación. Abre Tu marca para cambiar la paleta y las fuentes de la colección. Ocultar ajustes amplía la vista previa y conserva los valores actuales. Descargar HTML queda al pie del editor. Copiar HTML y Copiar CSS se agrupan en Copiar código.

## Integrar y exportar
Copiar HTML y Descargar HTML entregan un documento completo de una tarjeta con su texto, acento, profundidad e inclinación actuales. Conserva styles.css, script.js y assets/ junto a él. El editor y sus controles siguen funcionando. Copiar CSS incluye la hoja completa con sus estilos delimitados. No es un fragmento sin dependencias ni un componente React preparado. El ZIP completo es la referencia funcional; conserva contenedor ln-lab, atributos data-, scripts y diálogos que necesites.

Los únicos tokens cromáticos son los de assets/logo-lienzo.svg: #8b7bff, #6e5df2, #35d6c8, #ffb454, más blanco y el negro neutro del sitio. Las demás superficies derivan de esas mezclas y transparencias. No se incorpora el pack de iconos 3D: el responsable lo reserva para otras plantillas. Los relieves son geometría CSS. Fuentes locales Fraunces e Instrument Sans, con espaciado normal en los títulos.

## Créditos y límites
Implementación nueva de Lienzo para la colaboración con MD Estudio Creativo indicada por el responsable: https://creativomarketingdigital.com/ . El archivo neon-glass-3d-cards-ui-lab.zip y la grabación aportados se revisaron como referencias; no se redistribuye ni se cambia la licencia de su código. Consulta SOURCE-NOTES.md. Código Lienzo: MIT; fuentes: OFL; logos con sus derechos de marca. Conserva los avisos al compartir.

Ejemplo de interfaz reutilizable, no tienda completa, tema instalable de WordPress ni servicio de analítica. Sin cuentas, persistencia, subidas, pedidos ni pagos. Solo se descargan los archivos creados localmente al interactuar y el ZIP de Lienzo. Prueba tu texto e integración finales en los navegadores que vayas a admitir.


## Mesa de edición
El botón Ajustes pliega el inspector sin restablecer el trabajo. La vista previa permanece estable durante la edición. Conserva editor-workspace.css, editor-workspace.js, editor-legacy.css, editor-legacy.js, template-brand.css y template-brand.js junto al CSS, JavaScript, HTML y assets originales. Estos archivos locales no necesitan red ni instalación.

## Tu marca
Lienzo es la identidad de ejemplo predeterminada. Tu marca admite colores principal, secundario y acento libres, fondo/texto opcionales, fuentes del sistema y archivos WOFF2/WOFF/TTF/OTF locales de hasta 5 MB por función. Los cambios se aplican en directo a la pieza y son independientes de Aplicar/Cancelar contenido. Las exportaciones HTML completas incluyen el perfil y las fuentes adjuntas; conserva las dependencias del ZIP junto al HTML. Los SVG de iconos incluyen sus colores y no necesitan JavaScript; esos dibujos no tienen texto visible y no usan la fuente del editor. Adjunta únicamente fuentes que puedas utilizar y redistribuir. Ningún archivo sale del navegador.
