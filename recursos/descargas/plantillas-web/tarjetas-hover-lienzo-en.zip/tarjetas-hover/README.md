# Six CSS Card Hover Effects — Lienzo Hover Atelier

Six distinct interaction families: neon glow, lift, sweep/reveal, 3D rotation, living gradient, and float. Newly written Lienzo HTML/CSS/JS, 3D renders from the SVG Favicon Gallery, local fonts, keyboard focus, touch preview, light/dark themes, and reduced motion.

## Open, edit, and export

Extract the complete ZIP and open index.html. No server, framework, package install, API, network, account, analytics, or storage is required. Keep styles.css, script.js, assets/, and license notices together.

Customize edits one card: title, description, link text/destination, Lienzo accent, response duration 200–1000 ms, intensity 0–100%, corner radius 16–40 px, and smooth/snappy/spring easing. Changes apply immediately to the gallery and the before/after comparison. Reset affects only that card. Previous/next buttons switch cards without losing edits. Use At rest and With effect in the fixed preview. Fold the settings to enlarge the preview. Content opens first. Link, Appearance and motion, and Your brand are expandable groups. Replay runs a temporary effect; Try all six previews the collection. Paused/reduced motion disables moving effects, leaving static readable content. Hover and keyboard focus work without JavaScript; editing and touch preview require it.

Copy HTML/Download HTML exports a working document containing the current card and its settings, or the full collection. It is NOT a single self-contained file: keep the exported HTML beside CSS, JS, and assets/ from the ZIP. Clipboard-denied environments offer selectable text. The exported state preserves theme and pause, resets temporary tests, and escapes user text. Links accept HTTP(S), mailto, /path, ./file, ../file, and #fragment; JavaScript/data schemes and backslashes are rejected. Link changes never open a URL automatically. Default resource links open only when clicked.

## Source editing and integration

The data-effects JSON block stores key, name, description, label, href, accent, duration, intensity, radius, easing, and category. Valid keys: glow, lift, sweep, rotate, gradient, float. Accent: mint, violet, amber. Each card uses one local WebP render. Accent settings change the surface and effects around the image. Numbers are validated and bounded by the script. Text is assigned with textContent; links use a scheme allowlist. State stays in memory and resets on reload.

Keep .ln-hover-lab and the relevant data-* hooks/dialogs when integrating, or adapt initialization to your wrapper. This is static HTML/CSS/JS, not a React component or WordPress theme. The full ZIP is the working reference. The default interface uses the Lienzo palette. The renders keep their original colors. Fraunces tracking remains normal.

## Motion and performance

Transform and opacity drive animated layers. The sheen/reveal moves with transforms, not top/left. Neon glow crossfades a static shadow layer. Gradient rotation and float run only while visible; the toolbar pause, system reduced motion, hidden tabs, and modal backgrounds pause them. Pointer light/tilt uses cached geometry and batched requestAnimationFrame writes, not a permanent JS loop. Offscreen work is stopped with IntersectionObserver. The before comparison stays static; only the after card previews the interaction. Benchmarks are local observations, not universal FPS guarantees.

## Provenance and licenses

The supplied archive ultimate-css-card-animation-pack-6-unique-hover-effects.zip and screen-20261013-155959~2.mp4 were inspected as references. The archive contains nine cards, including repeated effect names/classes; shared selectors overwrite part of the shine/reveal and float definitions. This implementation groups the visual capabilities into six complete families, retaining the glass/perspective and neon variants without duplicate CSS collisions. Reference code, emojis, and styles are not redistributed. No third-party authorship or authorization is invented. The owner explicitly requested the local 3D library. Six WebP renders preserve the original colors and transparency. assets/ICONS-NOTICE.txt lists the source archives and members. The MIT code notice does not relicense these library assets.

Prepared for the Lienzo collaboration with MD Estudio Creativo identified by the project owner: https://creativomarketingdigital.com/ . Code is MIT under LICENSE-LIENZO.txt; fonts retain OFL notices. SOURCE-NOTES.md records provenance. MIT does not transfer trademark rights.


## Editing workspace
The Settings button folds the inspector without resetting your work. The preview stays in place while you edit. Keep editor-workspace.css, editor-workspace.js, editor-legacy.css, editor-legacy.js, template-brand.css, and template-brand.js beside the original CSS, JavaScript, HTML and assets. These local files need no network or installation.

## Your brand
Lienzo is the default sample identity. Your brand accepts custom primary, secondary, and accent colors, optional surface/text colors, system fonts, and local WOFF2/WOFF/TTF/OTF font files up to 5 MB per role. Changes apply live to the component; they are separate from content Apply/Cancel. Full HTML exports embed the brand profile and uploaded fonts; keep the ZIP dependencies alongside the HTML. SVG icon exports embed their chosen colors and need no JavaScript; these drawings contain no visible text and do not use the editor’s font. Only upload fonts you are allowed to use and redistribute. No upload leaves the browser.
