# Progress & Depth Carousel — Lienzo Form

Four transparent WebP renders from the Lienzo 3D library with a centered card, lateral previews, and synchronized image, shadow, card, text, and background movement.

## Open
Extract the entire ZIP and open index.html. Everything is local: images, fonts, Swiper 12.2.0, CSS, and JS. No installation, CDN, server, API key, account, or build step. The standalone demo starts in light mode; the Lienzo preview syncs to its parent theme.

## Controls
Drag with a mouse or swipe horizontally. Use the previous/next buttons, four progress indicators, or focus the stage and press ArrowLeft, ArrowRight, Home, or End. Tap a lateral product to bring it to the center. View details opens a native dialog; Escape closes it and restores focus. The optional autoplay starts off and waits 6.5 seconds per product. Its current indicator shows elapsed time. It pauses on hover, keyboard interaction, drag, open dialogs, transitions, and hidden tabs. System reduced motion disables autoplay and motion transitions. The depth toggle also stops automatic advancement.

## Customize
Open Settings to adjust transition duration (350–1400 ms), depth, autoplay, or the interface accent. The controls update the live preview. Open Your brand for the collection palette and fonts. Hide settings keeps your changes for the session.

Replace the sample WebP files in assets/ with your transparent product images. Edit the four articles' names, categories, prices, and image alt text in index.html. Keep data-products in the same document consistent with that content. It drives the details dialog. The example uses USD sample prices and does not process purchases or orders. Local fonts are Fraunces and Instrument Sans.

The image, shadow, scale, text masks, and background are mapped to each Swiper slide's progress. script.js includes setup, scoped keyboard input, velocity-sensitive drag settling, dialog focus handling, optional autoplay, motion preferences, and theme messages. Keep the stage, navigation, dialogs, product data, and scripts together. Copy complete HTML includes those controls and dependencies; it is not a dependency-free fragment. Retain assets/ beside the copied document. The full ZIP is the functional integration reference.

## Files and credits
New Lienzo implementation for the collaboration with MD Estudio Creativo identified by the project owner: https://creativomarketingdigital.com/ . The supplied Swiper carousel ZIP was reviewed as a visual/motion reference; its source code and remote Nike images are not redistributed. The four renders come from the Lienzo 3D library and serve as fictional product examples. See SOURCE-NOTES.md and assets/LICENSE-SWIPER.txt. Lienzo code: MIT; bundled Swiper: MIT; fonts: OFL. Preserve those notices when sharing the download. Logo marks retain their respective trademark rights.

## Limits
This is a reusable interface example, not a complete store, payment integration, installable WordPress theme, or ready-made React component. React requires lifecycle and markup adaptation. No analytics, persistence, account, backend, or external requests. Changes reset on reload. Inspect your final product images and test your own content before integration.


## Editing workspace
The Settings button folds the inspector without resetting your work. The preview stays in place while you edit. Keep editor-workspace.css, editor-workspace.js, editor-legacy.css, editor-legacy.js, template-brand.css, and template-brand.js beside the original CSS, JavaScript, HTML and assets. These local files need no network or installation.

## Your brand
Lienzo is the default sample identity. Your brand accepts custom primary, secondary, and accent colors, optional surface/text colors, system fonts, and local WOFF2/WOFF/TTF/OTF font files up to 5 MB per role. Changes apply live to the component; they are separate from content Apply/Cancel. Full HTML exports embed the brand profile and uploaded fonts; keep the ZIP dependencies alongside the HTML. SVG icon exports embed their chosen colors and need no JavaScript; these drawings contain no visible text and do not use the editor’s font. Only upload fonts you are allowed to use and redistribute. No upload leaves the browser.
